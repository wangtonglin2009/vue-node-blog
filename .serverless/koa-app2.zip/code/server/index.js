require('babel-core/register') // babel编译
module.exports = require('./app.js')
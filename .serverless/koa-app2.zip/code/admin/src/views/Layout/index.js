export { default as NavBar } from './navBar'
export { default as SlideBar } from './slideBar'
export { default as ContentView } from './content'

<template>
	<div class="none-data-wrapper">
		<img src="../../images/none-data.png" alt="">
	</div>
</template>
<style lang="less" scoped>
	.none-data-wrapper {
		text-align: center;
		.none-data-icon {
			font-size: 100px;
		}
	}
	
</style>